user: 010851646 (Juraszek, Lukasz)
