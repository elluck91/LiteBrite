package CS151.HW3;

import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

public class LiteBrite extends Application {

	private String value;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) {
		stage.setTitle("Enjoy The Light-Brite");
		Scene scene = new Scene(new VBox(), 520, 545);
		
		// default color of the scene
		scene.setFill(Color.OLDLACE);
		value = "#000000";
		final ColorPicker colorPicker = new ColorPicker();
		
		colorPicker.setOnAction(new EventHandler() {
			public void handle(Event t) {
				value = colorPicker.getValue().toString();
			}
		});

		int rows = 50;
		int columns = 50;

		GridPane grid = new GridPane();
		grid.getStyleClass().add("game-grid");

		for(int i = 0; i < columns; i++) {
			ColumnConstraints column = new ColumnConstraints(10);
			grid.getColumnConstraints().add(column);
		}

		for(int i = 0; i < rows; i++) {
			RowConstraints row = new RowConstraints(10);
			grid.getRowConstraints().add(row);
		}

		for (int i = 0; i < columns; i++) {
			for (int j = 0; j < rows; j++) {
				Pane pane = new Pane();
				pane.setOnMouseReleased(e -> {
					pane.setBackground(new Background(new BackgroundFill(Paint.valueOf(value), CornerRadii.EMPTY, Insets.EMPTY)));
				});
				pane.getStyleClass().add("game-grid-cell");
				if (i == 0) {
					pane.getStyleClass().add("first-column");
				}
				if (j == 0) {
					pane.getStyleClass().add("first-row");
				}
				grid.add(pane, i, j);
			}
		}

		grid.setVisible(true);
		scene.getStylesheets().add(LiteBrite.class.getResource("./game.css").toExternalForm());

		((VBox) scene.getRoot()).getChildren().addAll(colorPicker, grid);
		stage.setScene(scene);
		stage.show();
	}
}
